NEON MAZE - Android project source
Includes a mobile-friendly maze game in app/src/main/assets/index.html and a minimal Android WebView wrapper.
Features: three maze layouts, ghosts, a level-three boss with five strength points, collectible dash/shield/slow-motion powers, lives, pause and restart.
To build an APK: open this folder in Android Studio, allow Gradle sync, install Android SDK Platform 35 and a compatible Android Gradle Plugin toolchain, then Build > Build Bundle(s) / APK(s) > Build APK(s). The APK will be in app/build/outputs/apk/debug/.
This ZIP is source code, NOT a compiled APK. A local Android SDK/Gradle build environment is required to produce and test the APK.
